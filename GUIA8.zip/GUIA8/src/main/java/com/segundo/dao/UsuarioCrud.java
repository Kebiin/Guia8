
package com.segundo.dao;

import com.segundo.modelo.Usuario;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author family
 */@EnableJpaRepositories
public interface UsuarioCrud extends CrudRepository<Usuario, String>{
    
}
